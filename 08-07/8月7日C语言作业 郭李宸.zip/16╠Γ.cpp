#include<stdio.h>
#include <string.h>
struct student
{
	char num[100];
	char name[100];
	char gender;
	int age;
};
int main()
{
	int i,judge;
	judge=0;
	struct student person[]=
	{
		{"202501","张三",'F',18},
		{"202502","李四",'M',21},
		{"202503","王五",'M',19},
		{"202504","赵六",'F',22},
		{"202505","钱七",'M',21}
	};
	char number[20];
	printf("请输入学生学号:");
	scanf("%s",&number);
	for(i=0;i<=4;i++)
	{
		if(strcmp(number,person[i].num)==0)
		{
			printf("学生信息为：\n");
			printf("学号：%s\n",person[i].num);
			printf("姓名：%s\n",person[i].name);
			printf("性别：%c\n",person[i].gender);
			printf("年龄：%d\n",person[i].age);
			judge=1;
		}
	}
	if(judge==0)
		{
			printf("未找到该学生，请检查输入的学号！");
		}
	return 0;
}