#include <stdio.h>
int main()
{
	int month;							//设定输入的月份
	long int m1,m2,m,i;					//定义一月个数m1,二月m2,要计算的月份m，循环参数i
	m1=1;m2=1;
	printf("请输入要计算的月数：");
	scanf("%d",&month);
	if(month==1||month==2)				//对month值进行判断
	{
		printf("兔子总数为%ld\n",2);
		return 0;
	}
	if(month>2)
	{
		for(i=3;i<=month;i++)
		{
			m=m1+m2;
			m1=m2;
			m2=m;						//该变化为斐波拉契数列，规律为An=A(n-1)+A(n-2)
		}
	}
	printf("兔子总数为%ld\n",2*m);
	return 0;
}