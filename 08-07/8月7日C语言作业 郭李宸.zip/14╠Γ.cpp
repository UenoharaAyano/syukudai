#include <stdio.h>
#include <math.h>
int main()
{
	double A,B,C;
	double x1,x2,delta;
	printf("请输入A的值：");
	scanf("%lf",&A);
	printf("请输入B的值：");
	scanf("%lf",&B);
	printf("请输入C的值：");
	scanf("%lf",&C);              //键入A,B,C的值
	
	if(A==0)                      //对A值进行判断
	{
		printf("A不能为0!");
		return 0;
	}
	
	delta=B*B-4*A*C;              //算出delta，判断根
	
	if(delta>0)
	{
		x1=(-B+sqrt(delta))/(2*A);
		x2=(-B-sqrt(delta))/(2*A);
		printf("方程有两个不等实根，x1=%.3lf，x2=%.3lf\n",x1,x2);
	}
	if(delta==0)
	{
		x1=-B/(2*A);
		printf("方程有两个相等实根，为%.3lf\n",x1);
	}
	if(delta<0)
	{
		printf("方程无实根\n");
	}                             //根据不同delta值给出结果
	return 0;
}